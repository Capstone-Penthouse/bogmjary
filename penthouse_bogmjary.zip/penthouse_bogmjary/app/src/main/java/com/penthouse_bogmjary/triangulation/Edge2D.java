package com.penthouse_bogmjary.triangulation;

public class Edge2D {
    public Vector2D a;
    public Vector2D b;

    public Edge2D(Vector2D vector2D, Vector2D vector2D2) {
        this.a = vector2D;
        this.b = vector2D2;
    }
}
